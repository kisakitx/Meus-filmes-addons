import xbmcplugin
import xbmcgui
import requests
import sys

BASE_URL = "http://192.168.18.4:3000"

def listar_videos():
    r = requests.get(BASE_URL + "/videos-list")
    videos = r.json()
    for v in videos:
        url = BASE_URL + "/videos/" + v
        item = xbmcgui.ListItem(label=v)
        item.setInfo('video', {'title': v})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == "__main__":
    listar_videos()
