import xbmcplugin
import xbmcgui
import requests
import sys

# Substitua pelo IP real do seu celular, não localhost
BASE_URL = "http://192.168.18.4:3000"

def listar_videos():
    try:
        r = requests.get(BASE_URL + "/videos-list")
        r.raise_for_status()
        videos = r.json()
    except:
        xbmcgui.Dialog().notification("Erro", "Não foi possível acessar o servidor", xbmcgui.NOTIFICATION_ERROR)
        return

    for v in videos:
        url = f"{BASE_URL}/videos/{v}"
        item = xbmcgui.ListItem(label=v)
        item.setInfo('video', {'title': v})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == "__main__":
    listar_videos()
